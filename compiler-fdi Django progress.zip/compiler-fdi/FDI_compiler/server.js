const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const TEMP_DIR = path.join(__dirname, 'temp');
if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR);

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

const sessions = {};

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'compiler.html'));
});

// Using stdbuf to disable I/O buffering for all relevant languages.
const languageConfig = {
    c: { service: 'c', file: 'main.c', command: (file) => ['sh', '-c', `gcc ${file} -o a.out && stdbuf -i0 -o0 -e0 ./a.out`] },
    cpp: { service: 'cpp', file: 'main.cpp', command: (file) => ['sh', '-c', `g++ ${file} -o a.out && stdbuf -i0 -o0 -e0 ./a.out`] },
    // UPDATE: Java command now dynamically receives the class name to execute.
    java11: { service: 'java', command: (file, className) => ['sh', '-c', `javac ${file} && java -cp /usr/src/app ${className}`] },
    java8: { service: 'java8', command: (file, className) => ['sh', '-c', `javac ${file} && java -cp /usr/src/app ${className}`] },
    python3: { service: 'python', file: 'main.py', command: (file) => ['stdbuf', '-i0', '-o0', '-e0', 'python3', '-u', file] },
    python27: { service: 'python2', file: 'main.py', command: (file) => ['stdbuf', '-i0', '-o0', '-e0', 'python', '-u', file] },
    javascript: { service: 'javascript', file: 'main.js', command: (file) => ['stdbuf', '-i0', '-o0', '-e0', 'node', file] },
    php: { service: 'php', file: 'main.php', command: (file) => ['stdbuf', '-i0', '-o0', '-e0', 'php', file] },
    typescript: { service: 'typescript', file: 'main.mts', command: (file) => ['stdbuf', '-i0', '-o0', '-e0', 'node', '--no-warnings', '--loader', 'ts-node/esm', file] },
    sql: { service: 'sql', file: 'query.sql', command: (file) => ['sh', '-c', `sqlite3 -table -header -readonly /data/database.db < ${file}`] }
};

function cleanupSession(sessionId) {
    const session = sessions[sessionId];
    if (!session) return;

    if(session.timeoutId) clearTimeout(session.timeoutId);

    if (session.process) {
        session.process.removeAllListeners();
        session.process.kill('SIGKILL');
    }
    if (session.tempFilePath && fs.existsSync(session.tempFilePath)) {
        fs.unlinkSync(session.tempFilePath);
    }
    delete sessions[sessionId];
    console.log(`Cleaned up session: ${sessionId}`);
}

app.get('/schema', (req, res) => {
    const containerName = 'sql-compiler-container';
    // This command gets all table names, then for each table, gets its column info (name and type).
    const command = `
        sqlite3 /data/database.db -json " \
            SELECT m.name AS table_name, p.name AS column_name, p.type AS column_type \
            FROM sqlite_master AS m \
            JOIN pragma_table_info(m.name) AS p \
            WHERE m.type = 'table' AND m.name NOT LIKE 'sqlite_%' \
            ORDER BY m.name, p.cid; \
        "
    `;
    
    const execProc = spawn('docker', ['exec', containerName, 'sh', '-c', command]);

    let schemaData = '';
    let errorData = '';

    execProc.stdout.on('data', (data) => {
        schemaData += data.toString();
    });

    execProc.stderr.on('data', (data) => {
        errorData += data.toString();
    });

    execProc.on('close', (code) => {
        if (code !== 0) {
            console.error(`Schema fetch error: ${errorData}`);
            return res.status(500).json({ error: 'Failed to fetch schema from the database.', details: errorData });
        }
        try {
            const parsedSchema = JSON.parse(schemaData);
            // Group the flat list of columns by table name
            const groupedSchema = parsedSchema.reduce((acc, { table_name, column_name, column_type }) => {
                if (!acc[table_name]) {
                    acc[table_name] = [];
                }
                acc[table_name].push({ name: column_name, type: column_type });
                return acc;
            }, {});
            res.json(groupedSchema);
        } catch (e) {
            console.error(`Schema JSON parsing error: ${e.message}`);
            res.status(500).json({ error: 'Failed to parse the database schema.', details: schemaData });
        }
    });
});

app.post('/execute', (req, res) => {
    const { language, code } = req.body;

    if (language === 'sql') {
        const forbiddenKeywords = /\b(INSERT|UPDATE|DELETE|CREATE|DROP|ALTER|TRUNCATE|GRANT|REVOKE)\b/i;
        if (forbiddenKeywords.test(code)) {
            return res.status(403).json({ error: 'Forbidden SQL keyword detected. Only SELECT statements are allowed.' });
        }
    }

    const config = languageConfig[language];
    if (!config) return res.status(400).json({ error: `Unsupported language: ${language}` });

    const sessionId = uuidv4();

    // --- START: Dynamic Java filename logic ---
    let tempFileName;
    let mainClassName = 'Main'; // Default class name

    if (language === 'java11' || language === 'java8') {
        const match = code.match(/public\s+class\s+(\w+)/);
        if (match && match[1]) {
            mainClassName = match[1];
        }
        tempFileName = `${mainClassName}.java`;
    } else {
        tempFileName = config.file;
    }
    // --- END: Dynamic Java filename logic ---

    const tempFilePath = path.join(TEMP_DIR, `${sessionId}_${tempFileName}`);
    fs.writeFileSync(tempFilePath, code);

    const containerName = `${config.service}-compiler-container`;
    const containerPath = `/usr/src/app/${tempFileName}`;
    const copyCommand = ['cp', tempFilePath, `${containerName}:${containerPath}`];
    
    const copyProc = spawn('docker', copyCommand);
    let copyError = '';
    copyProc.stderr.on('data', (data) => { copyError += data.toString(); });

    copyProc.on('close', (copyCode) => {
        if (copyCode !== 0) {
            fs.unlinkSync(tempFilePath);
            return res.status(500).json({ error: 'Failed to prepare execution environment.', details: copyError });
        }
        
        // Pass the dynamically found class name to the command function for Java
        const commandParts = config.command(containerPath, mainClassName);
        const execProc = spawn('docker', ['exec', '-i', containerName, ...commandParts]);

        const session = {
            process: execProc,
            tempFilePath,
            language,
            output: '',
            error: '',
            cumulativeOutput: '',
            status: 'running',
            lastOutputTime: Date.now()
        };
        sessions[sessionId] = session;
        
        session.timeoutId = setTimeout(() => {
            console.log(`Session ${sessionId} timed out.`);
            session.error += '\n[Execution timed out after 30 seconds]\n';
            session.status = 'finished';
            execProc.kill('SIGKILL');
        }, 30000);

        res.json({ sessionId });

        execProc.stdout.on('data', (data) => {
            const outputStr = data.toString();
            session.output += outputStr;
            session.cumulativeOutput += outputStr;
            session.lastOutputTime = Date.now();
        });

        execProc.stderr.on('data', (data) => {
            const errorStr = data.toString();
            session.error += errorStr;
            session.cumulativeOutput += errorStr;
            session.lastOutputTime = Date.now();
        });

        execProc.on('close', (code) => {
            clearTimeout(session.timeoutId);
            session.status = 'finished';
            setTimeout(() => cleanupSession(sessionId), 5000);
        });

        execProc.on('error', (err) => {
            clearTimeout(session.timeoutId);
            session.error += `Execution failed: ${err.message}`;
            session.status = 'finished';
            setTimeout(() => cleanupSession(sessionId), 5000);
        });
    });
});

app.get('/poll/:sessionId', (req, res) => {
    const { sessionId } = req.params;
    const session = sessions[sessionId];

    if (!session) {
        return res.status(404).json({ status: 'finished', error: 'Session not found or has expired.' });
    }
    
    let isStillRunning = session.process.exitCode === null;
    
    if (isStillRunning && (session.language === 'javascript' || session.language === 'typescript')) {
        const isIdle = Date.now() - session.lastOutputTime > 500;
        
        if (isIdle && session.cumulativeOutput.length > 0) { 
            const promptRegex = /(?:\?|:|%|>|\$)\s*$/;
            const isWaitingForInput = promptRegex.test(session.cumulativeOutput);

            if (!isWaitingForInput) {
                isStillRunning = false;
                session.status = 'finished';
                session.process.kill('SIGKILL');
            }
        }
    }
    
    if (!isStillRunning && session.status !== 'finished') {
        session.status = 'finished';
    }

    const response = {
        sessionId,
        status: session.status,
        output: session.output,
        error: session.error,
        isStillRunning
    };

    session.output = '';
    session.error = '';

    res.json(response);
});

app.post('/submit-input', (req, res) => {
    const { sessionId, input } = req.body;
    const session = sessions[sessionId];
    
    if (!session || !session.process || !session.process.stdin.writable) {
        return res.status(404).json({ error: 'Session not found, not running, or cannot accept input.' });
    }
    
    session.process.stdin.write(input + '\n', (err) => {
        if (err) {
            session.status = 'finished';
            console.log(`Failed to write to stdin for session ${sessionId}, process may have closed.`);
            return res.status(200).json({ status: 'input-ignored-process-closed' });
        }
        session.cumulativeOutput += input + '\n'; // Also add user input to cumulative log
        session.lastOutputTime = Date.now();
        res.json({ status: 'input-submitted' });
    });
});

app.listen(PORT, () => {
    console.log(`Compiler backend listening on http://localhost:${PORT}`);
    fs.readdir(TEMP_DIR, (err, files) => {
        if (err) return;
        for (const file of files) {
            fs.unlink(path.join(TEMP_DIR, file), e => { if(e) console.error("Error cleaning temp file", e) });
        }
    });
});

