# assessment/urls.py

from django.urls import path
from . import views

urlpatterns = [
    # The home page where the user chooses Manual or Automatic
    path('', views.assessment_home, name='assessment_home'),
    
    # The page for manually creating a question
    path('manual/', views.manual_question_create, name='manual_question'),
    
    # The page that displays the question library
    path('library/', views.question_library, name='question_library'),
    
    # The API endpoint that provides question data as JSON
    path('api/questions/', views.get_questions_api, name='get_questions_api'),
]
