# assessment/views.py

import json
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Question, TestCase

def assessment_home(request):
    """
    Renders the initial assessment creation page (Libruary_Coding.html).
    """
    return render(request, 'Libruary_Coding.html')

@csrf_exempt
def manual_question_create(request):
    """
    Handles both rendering the manual question creation form and processing
    the POST request to save a new question.
    """
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            difficulty = data.get('difficulty') # Get the difficulty from the submitted data

            # Combine tags and selected topics from the form
            tags = data.get('tags', '')
            selected_topics = data.get('selected_topics', [])
            if selected_topics:
                topics_str = ', '.join(selected_topics)
                if tags:
                    tags = f"{tags}, {topics_str}"
                else:
                    tags = topics_str

            # Create the Question instance with all fields from the form
            question = Question.objects.create(
                title=data.get('title'),
                description=data.get('description'),
                difficulty=difficulty, # Save the difficulty
                depth_of_knowledge=data.get('depth_of_knowledge'),
                points=data.get('points'),
                time_to_answer=data.get('time_to_answer'),
                domain=data.get('domain'),
                tags=tags,
                hint=data.get('hint'),
                instructions=data.get('instructions'),
                available_in_interview=data.get('available_in_interview', False),
                enable_watermark=data.get('enable_watermark', True),
                deliver_fullscreen=data.get('deliver_fullscreen', False)
            )

            # Create associated TestCase instances
            test_cases_data = data.get('test_cases', [])
            for tc_data in test_cases_data:
                TestCase.objects.create(
                    question=question,
                    description=tc_data.get('description'),
                    input_data=tc_data.get('input_data'),
                    output_data=tc_data.get('output_data'),
                    categories=tc_data.get('categories'),
                    weightage=tc_data.get('weightage')
                )
            
            # --- MODIFICATION START ---
            # Determine the redirect level based on the question's difficulty
            redirect_level = ''
            if difficulty in ['Basic', 'Novice']:
                redirect_level = 'beginner'
            elif difficulty == 'Intermediate':
                redirect_level = 'intermediate'
            elif difficulty in ['Advanced', 'Expert']:
                redirect_level = 'advanced'
            
            # Construct a dynamic redirect URL with the level and the new question's ID
            redirect_url = f'/library/?level={redirect_level}&new_question_id={question.id}' if redirect_level else f'/library/?new_question_id={question.id}'
            
            return JsonResponse({'status': 'success', 'message': 'Question saved successfully!', 'redirect_url': redirect_url})
            # --- MODIFICATION END ---

        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)

    return render(request, 'Question_Coding.html')


def question_library(request):
    """
    Renders the question library page. The data is fetched by a separate API call.
    """
    return render(request, 'Libruary_Coding.html')

def get_questions_api(request):
    """
    API endpoint to fetch questions. If a 'level' parameter is provided in the URL,
    it filters the questions based on the difficulty level.
    """
    level = request.GET.get('level', None)
    
    questions = Question.objects.all()

    # Filter the queryset based on the provided level
    if level == 'beginner':
        questions = questions.filter(difficulty__in=['Basic', 'Novice'])
    elif level == 'intermediate':
        questions = questions.filter(difficulty='Intermediate')
    elif level == 'advanced':
        questions = questions.filter(difficulty__in=['Advanced', 'Expert'])
    
    # Order the results
    questions = questions.order_by('-created_at')
    
    questions_list = []
    for q in questions:
        questions_list.append({
            'id': q.id,
            'title': q.title,
            'description': q.description,
            'difficulty': q.difficulty,
            'points': q.points,
            'time_to_answer': q.time_to_answer,
            'hint': q.hint,
            'test_cases': list(q.test_cases.all().values('description', 'input_data', 'output_data', 'categories', 'weightage'))
        })
            
    return JsonResponse({'questions': questions_list})
